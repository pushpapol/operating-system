#include<stdio.h> 
#include<string.h> 
#include<stdlib.h> 
#include<sys/socket.h>
#include <netdb.h>
#include <sys/types.h>


struct dhcp_packet
{
	unsigned char OP,HTYPE,HLEN,HOPS;
	uint32_t XID;
	uint16_t SECS, FLAGS;
	unsigned char CIADDR[4];
	unsigned char YIADDR[4];
	unsigned char SIADDR[4];
	unsigned char GIADDR[4];
	unsigned char CHADDR[16];
	unsigned char SNAME[64];
	unsigned char FILE[128];
	unsigned char OPTIONS[312];
};
struct ipadd
{	struct dhcp_packet dhcp;
	unsigned char ONEADDR[1];
	unsigned char TWOADDR[1];
	unsigned char THREEADDR[1];
	};
int randm()
{int num;

num=rand()%3;
return num;	
	
}

			 

 
int main(int argc,char **argv)
{ srand ( time(NULL));
struct dhcp_packet dhcp_seg;
struct ipadd choice;
int rn;
    int sockfd, n,num,p,pol=1,push=1;
    int len = sizeof(struct sockaddr);
    struct sockaddr_in servaddr;
	FILE *fp;
	FILE *fp1;
   	unsigned short int src,des,temp,x,y;
	struct sockaddr_in cl_addr;
	char test_cond;
	int size=sizeof(cl_addr);

    sockfd=socket(AF_INET,SOCK_STREAM,0); 
    bzero(&servaddr,sizeof(servaddr));
 
    servaddr.sin_family=AF_INET;
    servaddr.sin_port=htons(atoi(argv[1])); // giving dynamic port number at the time of output to avoid any blocked ports
	inet_pton(AF_INET,"129.120.151.94",&(servaddr.sin_addr));
	//before connection set default values 
	choice.dhcp.OP=1;
	choice.dhcp.HTYPE=6;
	choice.dhcp.HLEN=1;
	choice.dhcp.HOPS=0;
	choice.dhcp.XID=123;
	choice.dhcp.SECS=3600;
	choice.dhcp.FLAGS=1;
	
    connect(sockfd,(struct sockaddr *)&servaddr,sizeof(servaddr)); // establishing connection with tcp server
	getsockname(sockfd,&cl_addr,&size);
	 
  //send yiadd as0.0.0.0 and transaction ID
  choice.dhcp.XID=123;
  choice.dhcp.YIADDR[0]=0;
  choice.dhcp.YIADDR[1]=0;
  choice.dhcp.YIADDR[2]=0;
  choice.dhcp.YIADDR[3]=0;
  choice.dhcp.CIADDR[0]=0;
  choice.dhcp.CIADDR[1]=0;
  choice.dhcp.CIADDR[2]=0;
  choice.dhcp.CIADDR[3]=0;
  send(sockfd,&choice,sizeof(struct ipadd),0);
 choice.ONEADDR[0]=0;
	choice.ONEADDR[1]=0;
	choice.ONEADDR[2]=0;
 
 recv(sockfd,&choice,sizeof(struct ipadd),0);
 printf("RECEIVED A PACKET FROM SERVER ASSAIGNING  IP \n");
 printf("|%4d|%3d|%3d|%4d|\n",choice.dhcp.OP,choice.dhcp.HTYPE,choice.dhcp.HLEN,choice.dhcp.HOPS);
 printf("|         %d     |\n|%8hd|%8hd|\n",choice.dhcp.XID,choice.dhcp.SECS,choice.dhcp.FLAGS);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.CIADDR[0],choice.dhcp.CIADDR[1],choice.dhcp.CIADDR[2],choice.dhcp.CIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.SIADDR[0],choice.dhcp.SIADDR[1],choice.dhcp.SIADDR[2],choice.dhcp.SIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.GIADDR[0],choice.dhcp.GIADDR[1],choice.dhcp.GIADDR[2],choice.dhcp.GIADDR[3]);
 printf("|%d.%d.%d -",choice.dhcp.YIADDR[0],choice.dhcp.YIADDR[1],choice.dhcp.YIADDR[2]);
 printf("%d,%d,%d|\n",choice.ONEADDR[0],choice.ONEADDR[1],choice.ONEADDR[2]);
 
 rn=randm();
 choice.dhcp.YIADDR[3]=choice.ONEADDR[rn];
 printf("The IP ADDRESS CHOSEN FROM THE PROVIDED IS |%d.%d.%d.%d|\n",choice.dhcp.YIADDR[0],choice.dhcp.YIADDR[1],choice.dhcp.YIADDR[2],choice.dhcp.YIADDR[3]);
 choice.dhcp.XID++;
 choice.dhcp.HOPS++;
 choice.dhcp.OP=1;
 choice.dhcp.CIADDR[0]=choice.dhcp.YIADDR[0];
  choice.dhcp.CIADDR[1]=choice.dhcp.YIADDR[1];
  choice.dhcp.CIADDR[2]=choice.dhcp.YIADDR[2];
  choice.dhcp.CIADDR[3]=choice.dhcp.YIADDR[3];
  
   
   send(sockfd,&choice,sizeof(struct ipadd),0);
   
   //receive an acknowledgement
   recv(sockfd,&choice,sizeof(struct dhcp_packet),0);
   printf("ACKNOWLEDGEMTN IS RECEIVED.IP ADDRESS IS SET\n");
   printf("|%4d|%3d|%3d|%4d|\n",choice.dhcp.OP,choice.dhcp.HTYPE,choice.dhcp.HLEN,choice.dhcp.HOPS);
 printf("|         %d     |\n|%8hd|%8hd|\n",choice.dhcp.XID,choice.dhcp.SECS,choice.dhcp.FLAGS);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.CIADDR[0],choice.dhcp.CIADDR[1],choice.dhcp.CIADDR[2],choice.dhcp.CIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.SIADDR[0],choice.dhcp.SIADDR[1],choice.dhcp.SIADDR[2],choice.dhcp.SIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.GIADDR[0],choice.dhcp.GIADDR[1],choice.dhcp.GIADDR[2],choice.dhcp.GIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.YIADDR[0],choice.dhcp.YIADDR[1],choice.dhcp.YIADDR[2],choice.dhcp.YIADDR[3]);
   
   
   
   
   
   
   
   
	close(sockfd);           // closing the socket and connection with server
}