#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include<time.h>
#include<stdlib.h>



int value[4];
int listen_fd, conn_fd,numbytes;
struct sockaddr_in servaddr;
struct sockaddr_in main_server;
struct dhcp_packet dhcp_seg;
struct ipadd choice;
struct hostent *server;


struct dhcp_packet
{
	unsigned char OP,HTYPE,HLEN,HOPS;
	uint32_t XID;
	uint16_t SECS, FLAGS;
	unsigned char CIADDR[4];
	unsigned char YIADDR[4];
	unsigned char SIADDR[4];
	unsigned char GIADDR[4];
	unsigned char CHADDR[16];
	unsigned char SNAME[64];
	unsigned char FILE[128];
	unsigned char OPTIONS[312];
};

struct ipadd
{	struct dhcp_packet dhcp;
	unsigned char ONEADDR[3];
	
	};
			 
int randm(int val,int x)
{int num,i;
num=rand()%x +val;
return num;	
	
}
receive_dhcp(window_size)
{
struct timeval tv = {window_size, 0};
setsockopt(conn_fd, SOL_SOCKET, SO_RCVTIMEO, (struct timeval *)&tv, sizeof(struct timeval));

	          numbytes=recv(conn_fd,&choice,sizeof(struct dhcp_packet),0);
			  printf("\nRECEIVED A PACKET BEFORE 3600 seconds WITH CHOICE OF IP ASSIGNED\n");
			  if(numbytes<0)
			  {printf("\nTimeout period is %d seconds",window_size);
				  return 1;
				}
 printf("|%4d|%3d|%3d|%4d|\n",choice.dhcp.OP,choice.dhcp.HTYPE,choice.dhcp.HLEN,choice.dhcp.HOPS);
 printf("|         %d     |\n|%8hd|%8hd|\n",choice.dhcp.XID,choice.dhcp.SECS,choice.dhcp.FLAGS);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.CIADDR[0],choice.dhcp.CIADDR[1],choice.dhcp.CIADDR[2],choice.dhcp.CIADDR[3]);
printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.SIADDR[0],choice.dhcp.SIADDR[1],choice.dhcp.SIADDR[2],choice.dhcp.SIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.GIADDR[0],choice.dhcp.GIADDR[1],choice.dhcp.GIADDR[2],choice.dhcp.GIADDR[3]);
  printf("|    %d.%d.%d %d|\n",choice.dhcp.YIADDR[0],choice.dhcp.YIADDR[1],choice.dhcp.YIADDR[2],choice.dhcp.YIADDR[3]);

	return 0;		  
	
	
}
int main(int argc,char **argv)
{
int d=255,x;
srand ( time(NULL));
char *str2,*str3;
size_t index = 0;
time_t window_size;


listen_fd = socket(AF_INET, SOCK_STREAM, 0);

bzero(&servaddr, sizeof(servaddr));

servaddr.sin_family = AF_INET;
servaddr.sin_addr.s_addr = htons(INADDR_ANY);
servaddr.sin_port = htons(atoi(argv[1]));        // giving dynamic port number at the time of output to avoid blocked ports
    str2 = argv[2]; 
	str3=argv[3];
	while (*argv[2]) {
        if (isdigit((unsigned char)*argv[2])) {
            value[index] *= 10;
            value[index] += *argv[2] - '0';
        } else {
            index++;
        }
        argv[2]++;
    }
    printf("Given GATEWAY,SUBNET:%s %s", str2,str3);
	printf("\nvalues in |%s|: %d %d %d %d\n",str2,value[0], value[1], value[2], value[3]);


bind(listen_fd,  (struct sockaddr *) &servaddr, sizeof(servaddr));
listen(listen_fd, 10);

  conn_fd = accept(listen_fd, (struct sockaddr*)NULL, NULL); // accepting connection request from client
   
  // receive yiadd as 0.0.0.0 and transaction ID
  
 recv(conn_fd,&choice,sizeof(struct ipadd),0);
 printf("RECEIVED A PACKET FROM CLIENT ASKING FOR IP ASSIGN\n");
 printf("|%4d|%3d|%3d|%4d|\n",choice.dhcp.OP,choice.dhcp.HTYPE,choice.dhcp.HLEN,choice.dhcp.HOPS);
 printf("|         %d     |\n|%8hd|%8hd|\n",choice.dhcp.XID,choice.dhcp.SECS,choice.dhcp.FLAGS);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.CIADDR[0],choice.dhcp.CIADDR[1],choice.dhcp.CIADDR[2],choice.dhcp.CIADDR[3]);
 printf("|%5d.%3d.%3d.%3d|\n",choice.dhcp.YIADDR[0],choice.dhcp.YIADDR[1],choice.dhcp.YIADDR[2],choice.dhcp.YIADDR[3]);
	x=d-value[3];	
  choice.dhcp.HOPS++;
  choice.dhcp.OP=2;//reply
  choice.dhcp.GIADDR[0]=choice.dhcp.YIADDR[0]=value[0];
  choice.dhcp.GIADDR[1]=choice.dhcp.YIADDR[1]=value[1];
  choice.dhcp.GIADDR[2]=choice.dhcp.YIADDR[2]=value[2];
  choice.dhcp.GIADDR[3]=value[3];
  choice.ONEADDR[0]= randm(value[3],x);	
  choice.ONEADDR[1]=randm(value[3],x);
  choice.ONEADDR[2]=randm(value[3],x);
  choice.dhcp.SIADDR[0]=129;
  choice.dhcp.SIADDR[1]=120;
  choice.dhcp.SIADDR[2]=151;
  choice.dhcp.SIADDR[3]=94;  
  printf("%d,%d,%d|\n",choice.ONEADDR[0],choice.ONEADDR[1],choice.ONEADDR[2]);

  send(conn_fd,&choice,sizeof(struct ipadd),0);
  
  //mark the new address and store it and print it.

	if(receive_dhcp(window_size)==0)
		{
			printf("\nThe client accepted the IP address and got response\n");
		
		}
		else
		{
		printf("\nResend");
		send(conn_fd,&choice.dhcp,sizeof(struct ipadd),0);
			
		}
	//Send an acknowledgement.
	
	  choice.dhcp.HOPS++;
	  choice.dhcp.OP=2;//reply
	send(conn_fd,&choice,sizeof(struct ipadd),0);
	printf("ACKNOWLEDGMENT IS SENT\n");	
		
	
		
		
			
		
		

  close (conn_fd); // closing the connection with client

  }